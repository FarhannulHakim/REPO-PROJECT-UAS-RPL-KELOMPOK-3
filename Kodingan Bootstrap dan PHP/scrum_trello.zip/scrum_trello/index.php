<?php
session_start();
include "koneksi.php";

if ($_POST) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $q = mysqli_query($conn,
        "SELECT * FROM user 
         WHERE email='$email' AND password='$password'");

    if (mysqli_num_rows($q) > 0) {
        $_SESSION['login'] = true;
        header("Location: dashboard.php");
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body class="container mt-5">

<h3>Login</h3>
<form method="POST">
    <input class="form-control mb-2" name="email" placeholder="Email">
    <input class="form-control mb-2" name="password" type="password" placeholder="Password">
    <button class="btn btn-primary">Login</button>
</form>

</body>
</html>
