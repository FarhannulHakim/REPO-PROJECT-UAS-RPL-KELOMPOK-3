<?php
include "../koneksi.php";

$id = $_GET['id'];
$data = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM list WHERE id_list=$id")
);

if(isset($_POST['update'])){
    $nama_list = $_POST['nama_list'];

    mysqli_query($conn,
        "UPDATE list SET nama_list='$nama_list' WHERE id_list=$id");

    header("Location: ../list/index.php?id_board=".$id_board);
}
?>

<?php include "../layout/header.php"; ?>

<h4>Edit List</h4>

<form method="post">
    <div class="mb-3">
        <label>Nama List</label>
        <input type="text" name="nama_list" class="form-control"
               value="<?= $data['nama_list'] ?>" required>
    </div>

    <button name="update" class="btn btn-warning">Update</button>
</form>

<?php include "../layout/footer.php"; ?>
