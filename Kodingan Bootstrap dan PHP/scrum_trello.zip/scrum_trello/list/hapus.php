<?php
include "../koneksi.php";

$id = $_GET['id'];
$id_board = $_GET['id_board'];

mysqli_query($conn, "DELETE FROM list WHERE id_list=$id");

header("Location: ../list/index.php?id_board=".$id_board);

