<?php
session_start();
include "../koneksi.php";

if (!isset($_GET['id_board']) || $_GET['id_board'] == '') {
    header("Location: ../card/index.php");
    exit;
}

$id_board = (int) $_GET['id_board'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scrum Board - Kanban Style</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background-color: #f4f5f7;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #172b4d;
        }

        /* Container Board utama agar bisa scroll horizontal */
        .board-container {
            display: flex;
            gap: 1.25rem;
            padding: 20px;
            align-items: flex-start;
            overflow-x: auto;
            min-height: calc(100vh - 150px);
        }

        /* Styling Kolom List */
        .list-column {
            background-color: #ebecf0;
            border-radius: 12px;
            width: 300px;
            min-width: 300px;
            padding: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            display: flex;
            flex-direction: column;
        }

        .list-header {
            padding: 8px 4px;
            margin-bottom: 10px;
        }

        .list-header strong {
            font-size: 1rem;
            color: #172b4d;
        }

        /* Tombol Tambah List (Gradient) */
        .btn-add-list {
            background: linear-gradient(135deg, #0052cc 0%, #0071ff 100%);
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 82, 204, 0.3);
            text-decoration: none;
        }

        .btn-add-list:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 82, 204, 0.4);
            color: white;
        }

        /* Styling Card (Tugas) */
        .card-item {
            background-color: #fff;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 10px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-bottom: 2px solid #dfe1e6;
            transition: transform 0.1s ease, box-shadow 0.1s ease;
            cursor: pointer;
        }

        .card-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
            background-color: #f9fafb;
        }

        .card-name {
            display: block;
            font-weight: 500;
            margin-bottom: 8px;
            color: #333;
        }

        /* Tombol Aksi di dalam Card & List */
        .action-icon {
            font-size: 0.75rem;
            color: #6b778c;
            text-decoration: none;
            margin-left: 8px;
            transition: color 0.2s;
        }

        .action-icon:hover { color: #0052cc; }
        .action-icon.delete:hover { color: #de350b; }

        /* Tombol Tambah Card (Ghost style) */
        .btn-add-card {
            display: flex;
            align-items: center;
            gap: 8px;
            width: 100%;
            padding: 10px;
            background-color: transparent;
            color: #5e6c84;
            border: none;
            border-radius: 8px;
            text-align: left;
            font-weight: 500;
            transition: background-color 0.2s;
            text-decoration: none;
        }

        .btn-add-card:hover {
            background-color: rgba(9, 30, 66, 0.08);
            color: #172b4d;
        }

        /* Scrollbar custom agar cantik */
        .board-container::-webkit-scrollbar { height: 10px; }
        .board-container::-webkit-scrollbar-track { background: #dfe1e6; border-radius: 10px; }
        .board-container::-webkit-scrollbar-thumb { background: #bfccd6; border-radius: 10px; }
    </style>
</head>
<body>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-5 px-3">
        <div>
            <h2 class="fw-bold m-0">Project Board</h2>
            <p class="text-muted small m-0">Kelola tugas tim Anda dengan mudah</p>
        </div>
        <a href="tambah.php?id_board=<?= $id_board ?>" class="btn-add-list">
            <i class="fa-solid fa-plus me-2"></i> Tambah List Baru
        </a>
    </div>

    <div class="board-container">

    <?php
    $q = mysqli_query($conn, "SELECT * FROM list WHERE id_board = $id_board");
    while($l = mysqli_fetch_assoc($q)){
    ?>
        <div class="list-column">
            <div class="list-header d-flex justify-content-between align-items-center">
                <strong><?= $l['nama_list'] ?></strong>
                <div class="d-flex">
                    <a href="edit.php?id=<?= $l['id_list'] ?>" class="action-icon" title="Edit List">
                        <i class="fa-solid fa-pen"></i>
                    </a>
                    <a href="hapus.php?id=<?= $l['id_list'] ?>&id_board=<?= $id_board ?>" 
                       class="action-icon delete" 
                       onclick="return confirm('Hapus list ini?')" title="Hapus List">
                        <i class="fa-solid fa-trash"></i>
                    </a>
                </div>
            </div>

            <div class="cards-wrapper">
                <?php
                $qc = mysqli_query($conn, "SELECT * FROM card WHERE id_list=".$l['id_list']);
                while($c = mysqli_fetch_assoc($qc)){
                ?>
                <div class="card-item">
                    <span class="card-name"><?= $c['nama_card'] ?></span>
                    <div class="d-flex justify-content-end border-top pt-2 mt-2">
                        <a href="../card/edit.php?id=<?= $c['id_card'] ?>&id_board=<?= $id_board ?>" 
                           class="action-icon" title="Edit Card">
                            <i class="fa-solid fa-pencil"></i>
                        </a>
                        <a href="../card/hapus.php?id=<?= $c['id_card'] ?>&id_list=<?= $l['id_list'] ?>&id_board=<?= $id_board ?>" 
                           class="action-icon delete" 
                           onclick="return confirm('Hapus card ini?')" title="Hapus Card">
                            <i class="fa-solid fa-trash-can"></i>
                        </a>
                    </div>
                </div>
                <?php } ?>
            </div>

            <a href="../card/tambah.php?id_list=<?= $l['id_list'] ?>&id_board=<?= $id_board ?>" class="btn-add-card">
                <i class="fa-solid fa-plus"></i> Tambah Card Baru
            </a>
        </div>
    <?php } ?>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function confirmDelete(msg) {
        return confirm(msg);
    }
</script>
</body>
</html>