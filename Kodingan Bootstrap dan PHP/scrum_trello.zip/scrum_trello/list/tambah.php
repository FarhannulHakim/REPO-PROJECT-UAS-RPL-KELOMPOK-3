<?php
include "../koneksi.php";

$id_board = $_GET['id_board'];

if(isset($_POST['simpan'])){
    $nama_list = $_POST['nama_list'];

    mysqli_query($conn,
        "INSERT INTO list (nama_list, id_board)
         VALUES ('$nama_list', '$id_board')");

    header("Location: ../list/index.php?id_board=".$id_board);
}
?>

<?php include "../layout/header.php"; ?>

<h4>Tambah List</h4>

<form method="post">
    <div class="mb-3">
        <label>Nama List</label>
        <input type="text" name="nama_list" class="form-control" required>
    </div>

    <button name="simpan" class="btn btn-primary">Simpan</button>
    <a href="index.php?id_board=<?= $id_board ?>" class="btn btn-secondary">Kembali</a>
</form>

<?php include "../layout/footer.php"; ?>
