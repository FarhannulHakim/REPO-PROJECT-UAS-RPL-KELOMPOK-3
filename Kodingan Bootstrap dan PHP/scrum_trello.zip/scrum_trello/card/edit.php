<?php
include "../koneksi.php";

$id = $_GET['id'];
$data = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM card WHERE id_card=$id")
);

if(isset($_POST['update'])){
    $nama_card = $_POST['nama_card'];

    mysqli_query($conn,
        "UPDATE card SET nama_card='$nama_card' WHERE id_card=$id");

    header("Location: ../list/index.php?id_board=".$_GET['id_board']);
}
?>

<?php include "../layout/header.php"; ?>

<h4>Edit Card</h4>

<form method="post">
    <div class="mb-3">
        <label>Nama Task</label>
        <input type="text" name="nama_card"
               class="form-control"
               value="<?= $data['nama_card'] ?>" required>
    </div>

    <button name="update" class="btn btn-warning">Update</button>
</form>

<?php include "../layout/footer.php"; ?>
