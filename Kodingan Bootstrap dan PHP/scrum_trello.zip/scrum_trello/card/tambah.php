<?php
include "../koneksi.php";

$id_list = $_GET['id_list'] ?? null;
$id_board = $_GET['id_board'] ?? null;

if (isset($_POST['simpan'])) {
    $nama_card = $_POST['nama_card'];
    $id_list_post = $_POST['id_list'];

    mysqli_query($conn,
        "INSERT INTO card (nama_card, id_list)
         VALUES ('$nama_card', '$id_list_post')");

    if ($id_board) {
        header("Location: ../list/index.php?id_board=$id_board");
    } else {
        header("Location: index.php");
    }
}
?>

<?php include "../layout/header.php"; ?>

<h4>Tambah Card / Task</h4>

<form method="post">

    <div class="mb-3">
        <label>Nama Task</label>
        <input type="text" name="nama_card" class="form-control" required>
    </div>

    <?php if ($id_list == null) { ?>
        <!-- MODE MENU CARD -->
        <div class="mb-3">
            <label>Status (List)</label>
            <select name="id_list" class="form-control" required>
                <option value="">-- Pilih List --</option>
                <?php
                $q = mysqli_query($conn, "SELECT * FROM list");
                while($l = mysqli_fetch_assoc($q)){
                ?>
                    <option value="<?= $l['id_list'] ?>">
                        <?= $l['nama_list'] ?>
                    </option>
                <?php } ?>
            </select>
        </div>
    <?php } else { ?>
        <!-- MODE DARI LIST -->
        <input type="hidden" name="id_list" value="<?= $id_list ?>">
    <?php } ?>

    <button name="simpan" class="btn btn-primary">Simpan</button>
    <a href="index.php" class="btn btn-secondary">Kembali</a>

</form>

<?php include "../layout/footer.php"; ?>
