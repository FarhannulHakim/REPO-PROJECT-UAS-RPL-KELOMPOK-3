<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php");
}

include "../koneksi.php";
?>

<?php
$q = mysqli_query($conn,
"SELECT 
    card.id_card,
    card.nama_card,
    list.nama_list,
    board.nama_board
FROM card
JOIN list ON card.id_list = list.id_list
JOIN board ON list.id_board = board.id_board
ORDER BY board.nama_board, list.nama_list
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Card / Task</title>
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">

    <h3 class="mb-3">Data Card / Task</h3>

    <a href="tambah.php" class="btn btn-primary mb-3">
        + Tambah Task
    </a>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Board</th>
                <th>Task</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>

        <?php
        $no = 1;
        while ($r = mysqli_fetch_assoc($q)) {
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $r['nama_board'] ?></td>
            <td><?= $r['nama_card'] ?></td>
            <td>
                <span class="badge bg-info">
                    <?= $r['nama_list'] ?>
                </span>
            </td>
            <td>
                <a href="edit.php?id=<?= $r['id_card'] ?>"
                   class="btn btn-warning btn-sm">
                   Edit
                </a>
                <a href="hapus.php?id=<?= $r['id_card'] ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Hapus task ini?')">
                   Hapus
                </a>
            </td>
        </tr>
        <?php } ?>

        </tbody>
    </table>

</div>

<script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

