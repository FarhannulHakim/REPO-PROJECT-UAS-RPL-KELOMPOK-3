<?php
include "../koneksi.php";
mysqli_query($conn, "DELETE FROM card WHERE id_card='$_GET[id]'");
header("Location: ../list/index.php?id_board=".$id_board);
?>
<a href="hapus.php?id=<?= $id ?>"
   class="btn btn-danger btn-sm"
   onclick="return confirmDelete()">
   Hapus
</a>
