<?php
include "../koneksi.php";

$id = $_GET['id'];
$project = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM project WHERE id_project='$id'")
);
?>

<h2>Edit Project</h2>

<form method="POST">
    Nama Project <br>
    <input type="text" name="nama_project"
           value="<?= $project['nama_project'] ?>" required><br><br>

    Owner Project <br>
    <select name="id_user" required>
        <?php
        $users = mysqli_query($conn, "SELECT * FROM user");
        while ($u = mysqli_fetch_assoc($user)) {
            $selected = ($u['id'] == $project['id_user']) ? "selected" : "";
            echo "<option value='{$u['id']}' $selected>{$u['nama']}</option>";
        }
        ?>
    </select><br><br>

    <button type="submit">Update</button>
    <a href="project.php">Kembali</a>
</form>

<?php
if ($_POST) {
    mysqli_query($conn, "UPDATE projects SET
        nama_project='$_POST[nama_project]',
        user_id='$_POST[user_id]'
        WHERE id='$id'");

    header("Location: project.php");
}
?>
