<?php
include "../koneksi.php";

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM project WHERE id_project='$id'");
header("Location: project.php");
?>
