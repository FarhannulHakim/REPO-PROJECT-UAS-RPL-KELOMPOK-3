<?php
include "../koneksi.php";
?>

<h2>Tambah Project</h2>

<form method="POST">
    Nama Project <br>
    <input type="text" name="nama_project" required><br><br>

    Owner Project <br>
    <select name="id_user" required>
        <option value="">-- Pilih User --</option>
        <?php
        $users = mysqli_query($conn, "SELECT * FROM user");
        while ($u = mysqli_fetch_assoc($user)) {
            echo "<option value='{$u['id']}'>{$u['nama']}</option>";
        }
        ?>
    </select><br><br>

    <button type="submit">Simpan</button>
    <a href="project.php">Kembali</a>
</form>

<?php
if ($_POST) {
    mysqli_query($conn, "INSERT INTO project 
        (nama_project, id_user) 
        VALUES 
        ('$_POST[nama_project]', '$_POST[id_user]')");

    header("Location: project.php");
}
?>
