<?php include "../koneksi.php"; ?>

<h2>Data Project</h2>
<a href="tambah.php">Tambah Project</a><br><br>

<?php
$data = mysqli_query($conn,
"SELECT `project`.*, `user`.nama 
 FROM `project` 
 JOIN `user` ON `project`.id_user = `user`.id_user");

while ($p = mysqli_fetch_assoc($data)) {
    echo $p['nama_project']." - ".$p['nama']." | ";
    echo "<a href='edit.php?id=".$p['id_project']."'>Edit</a> | ";
    echo "<a href='hapus.php?id=".$p['id_project']."'>Hapus</a><br>";
}
?>
