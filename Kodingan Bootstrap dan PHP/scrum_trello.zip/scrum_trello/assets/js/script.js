// Pastikan script berjalan setelah halaman dimuat
document.addEventListener("DOMContentLoaded", function () {
    console.log("Custom script berhasil dimuat");
});

/*
|--------------------------------------------------------------------------
| Konfirmasi Hapus Data
|--------------------------------------------------------------------------
| Digunakan untuk board, list, dan card
*/
function confirmDelete(pesan = "Apakah Anda yakin ingin menghapus data ini?") {
    return confirm(pesan);
}
