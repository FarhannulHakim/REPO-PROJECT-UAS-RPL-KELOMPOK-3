<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: index.php");
}
?>

<?php
include "koneksi.php";

// hitung data
$jml_board = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM board"));
$jml_card  = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM card"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">

    <h3 class="mb-4">Dashboard – Agile Scrum Management</h3>

    <div class="row">

        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <h5>Total Board</h5>
                    <h2><?= $jml_board ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-white bg-success mb-3">
                <div class="card-body">
                    <h5>Total Task</h5>
                    <h2><?= $jml_card ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card bg-light mb-3">
                <div class="card-body">
                    <h5>Menu</h5>
                    <a href="board/index.php" class="btn btn-primary btn-sm">Board</a>
                    <a href="card/index.php" class="btn btn-success btn-sm">Card</a>
                    <a href="laporan/laporan.php" class="btn btn-dark btn-sm">Laporan</a>
                    <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
                </div>
            </div>
        </div>

    </div>

</div>

<script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

