<?php
$conn = mysqli_connect("localhost", "root", "", "db_scrumtrello");

if (!$conn) {
    die("Koneksi gagal");
}
?>
