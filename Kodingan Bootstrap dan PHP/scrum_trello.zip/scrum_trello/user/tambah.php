<?php include "../koneksi.php"; ?>

<form method="POST">
    Nama: <input type="text" name="nama"><br>
    Email: <input type="email" name="email"><br>
    Password: <input type="password" name="password"><br>
    <button type="submit">Simpan</button>
</form>

<?php
if ($_POST) {
    mysqli_query($conn, "INSERT INTO users VALUES (
        null,
        '$_POST[nama]',
        '$_POST[email]',
        '$_POST[password]'
    )");
    header("Location: user.php");
}
?>
