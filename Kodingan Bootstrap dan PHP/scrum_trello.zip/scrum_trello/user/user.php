<?php include "../koneksi.php"; ?>

<h2>Data User</h2>
<a href="tambah.php">Tambah User</a><br><br>

<?php
$data = mysqli_query($conn, "SELECT * FROM user");
while ($u = mysqli_fetch_assoc($data)) {
    echo $u['nama']." | ";
    echo "<a href='edit.php?id=".$u['id_user']."'>Edit</a> | ";
    echo "<a href='hapus.php?id=".$u['id_user']."'>Hapus</a><br>";
}
?>
