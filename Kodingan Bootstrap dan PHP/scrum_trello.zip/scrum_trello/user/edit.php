<?php
include "../koneksi.php";
$data = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT * FROM `user` WHERE id_user='$_GET[id]'"));
?>

<form method="POST">
    Nama: <input value="<?= $data['nama'] ?>" name="nama"><br>
    Email: <input value="<?= $data['email'] ?>" name="email"><br>
    <button type="submit">Update</button>
</form>

<?php
if ($_POST) {
    mysqli_query($conn, "UPDATE user SET
        nama='$_POST[nama]',
        email='$_POST[email]'
        WHERE id_user='$_GET[id]'");
    header("Location: user.php");
}
?>
