<?php
include "../koneksi.php";
mysqli_query($conn, "DELETE FROM user WHERE id_user='$_GET[id]'");
header("Location: user.php");
?>
