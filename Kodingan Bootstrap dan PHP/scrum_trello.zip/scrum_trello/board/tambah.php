<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php");
}

include "../koneksi.php";
?>

<?php
if (isset($_POST['simpan'])) {
    $nama_board = $_POST['nama_board'];
    $id_project = $_POST['id_project'];

    mysqli_query($conn,
        "INSERT INTO board (nama_board, id_project)
         VALUES ('$nama_board', '$id_project')");

    header("Location: index.php");
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Board</title>
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">

    <h3 class="mb-4">Tambah Board</h3>

    <div class="card">
        <div class="card-body">

            <form method="post">

                <div class="mb-3">
                    <label class="form-label">Nama Board</label>
                    <input type="text"
                           name="nama_board"
                           class="form-control"
                           placeholder="Contoh: Sprint 1"
                           required>
                </div>
                <div class="mb-3">
    <label class="form-label">Project</label>
    <select name="id_project" class="form-control" required>
        <option value="">-- Pilih Project --</option>
        <?php
        $q = mysqli_query($conn, "SELECT * FROM project");
        while ($p = mysqli_fetch_assoc($q)) {
        ?>
            <option value="<?= $p['id_project'] ?>">
                <?= $p['nama_project'] ?>
            </option>
        <?php } ?>
    </select>
</div>

                <button type="submit"
                        name="simpan"
                        class="btn btn-primary">
                    Simpan
                </button>

                <a href="index.php" class="btn btn-secondary">
                    Kembali
                </a>

            </form>

        </div>
    </div>

</div>

<script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

