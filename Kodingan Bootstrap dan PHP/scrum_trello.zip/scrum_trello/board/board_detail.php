<?php
include "../koneksi.php";

$board_id = isset($_GET['id']) ? $_GET['id'] : 0;

// Ambil semua list
$list = mysqli_query($conn,
    "SELECT * FROM list WHERE id_board='$board_id'");
?>

<div style="display:flex; gap:20px;">
<?php while ($l = mysqli_fetch_assoc($list)) { ?>
    
    <div style="width:250px; background:#f4f4f4; padding:10px;">
        <h3><?= $l['nama_list'] ?></h3>

        <?php
        // Ambil card berdasarkan list
        $card = mysqli_query($conn,
            "SELECT * FROM card WHERE id_list='".$l['id_list']."'");
        while ($c = mysqli_fetch_assoc($card)) {
            echo "<div style='background:white; margin:5px; padding:5px;'>";
            echo "<b>".$c['nama_card']."</b><br>";
            echo $c['deskripsi'];
            echo "</div>";
        }
        ?>
    </div>

<?php } ?>
</div>
