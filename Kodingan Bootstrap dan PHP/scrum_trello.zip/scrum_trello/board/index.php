<?php 
include "../koneksi.php";
include "../layout/header.php";
?>

<h3 class="mb-3">Sprint Board</h3>

<a href="tambah.php" class="btn btn-primary mb-3">+ Tambah Board</a>

<div class="row">
<?php
$q = mysqli_query($conn, "SELECT * FROM board");
while($b = mysqli_fetch_assoc($q)){
?>
    <div class="col-md-4">
        <div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title"><?= $b['nama_board'] ?></h5>

        <a href="../list/index.php?id_board=<?= $b['id_board'] ?>"
            class="btn btn-info btn-sm">
            Lihat List
            </a>

        <a href="edit.php?id=<?= $b['id_board'] ?>"
           class="btn btn-warning btn-sm">Edit</a>

        <a href="hapus.php?id=<?= $b['id_board'] ?>"
           class="btn btn-danger btn-sm"
           onclick="return confirmDelete('Yakin hapus board ini?')">
           Hapus
        </a>
    </div>
</div>

    </div>
<?php } ?>
</div>

<?php include "../layout/footer.php"; ?>
