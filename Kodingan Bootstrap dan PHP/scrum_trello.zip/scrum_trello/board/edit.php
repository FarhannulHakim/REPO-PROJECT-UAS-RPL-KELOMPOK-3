<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php");
}

include "../koneksi.php";
?>
<?php
$id = $_GET['id'];

$data = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM board WHERE id_board = $id")
);
?>

<?php
if (isset($_POST['update'])) {
    $nama_board = $_POST['nama_board'];
    $id_project = $_POST['id_project'];

    mysqli_query($conn,
        "UPDATE board 
         SET nama_board='$nama_board',
             id_project='$id_project'
         WHERE id_board=$id");

    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Board</title>
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">

    <h3 class="mb-4">Edit Board</h3>

    <div class="card">
        <div class="card-body">

            <form method="post">

                <div class="mb-3">
                    <label class="form-label">Nama Board</label>
                    <input type="text"
                           name="nama_board"
                           class="form-control"
                           value="<?= $data['nama_board'] ?>"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Project</label>
                    <select name="id_project" class="form-control" required>
                        <?php
                        $qp = mysqli_query($conn, "SELECT * FROM project");
                        while ($p = mysqli_fetch_assoc($qp)) {
                            $selected = ($p['id_project'] == $data['id_project']) ? 'selected' : '';
                        ?>
                            <option value="<?= $p['id_project'] ?>" <?= $selected ?>>
                                <?= $p['nama_project'] ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <button type="submit"
                        name="update"
                        class="btn btn-warning">
                    Update
                </button>

                <a href="index.php" class="btn btn-secondary">
                    Kembali
                </a>

            </form>

        </div>
    </div>

</div>

<script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

