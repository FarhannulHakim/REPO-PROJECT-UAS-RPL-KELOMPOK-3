<?php
include "../koneksi.php";
include "../layout/header.php";
?>

<h3 class="mb-4">Laporan Progress Task</h3>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>No</th>
            <th>Board</th>
            <th>Task</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $no = 1;
    $q = mysqli_query($conn,
        "SELECT 
            board.nama_board,
            card.nama_card,
            list.nama_list
         FROM card
         JOIN list ON card.id_list = list.id_list
         JOIN board ON list.id_board = board.id_board
         ORDER BY board.nama_board, list.nama_list
        ");

    while($r = mysqli_fetch_assoc($q)){
    ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $r['nama_board'] ?></td>
            <td><?= $r['nama_card'] ?></td>
            <td>
                <span class="badge bg-primary">
                    <?= $r['nama_list'] ?>
                </span>
            </td>
        </tr>
    <?php } ?>
    </tbody>
</table>

<?php include "../layout/footer.php"; ?>
