<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Scrum Trello</title>

    <!-- Bootstrap Lokal -->
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">

    <!-- CSS Custom -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
        <span class="navbar-brand">Scrum Trello App</span>
    </div>
</nav>

<div class="container mt-4">
<li class="nav-item">
    <a class="nav-link" href="../laporan/index.php">
        Laporan
    </a>
</li>

